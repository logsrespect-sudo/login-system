package javaapplicationpart1;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class QuickchatsTest {

    private Quickchats validMessage;
    private final PrintStream originalOut = System.out;
    private ByteArrayOutputStream outContent;

    @Before
    public void setUp() throws Exception {
        // sentMessages is a private static list, so clear it by reflection
        // to stop one test's data leaking into the next.
        Field field = Quickchats.class.getDeclaredField("sentMessages");
        field.setAccessible(true);
        ((ArrayList<?>) field.get(null)).clear();

        validMessage = new Quickchats("0012345678", 1, "+27718693002",
                "Hi Mike, can you join us for dinner tonight");

        outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
    }

    @After
    public void tearDown() {
        System.setOut(originalOut);
    }

    // ---------- Constructor / getters ----------

    @Test
    public void testConstructorAndGetters() {
        assertEquals("0012345678", validMessage.getMessageID());
        assertEquals(1, validMessage.getMessageNumber());
        assertEquals("+27718693002", validMessage.getRecipient());
        assertEquals("Hi Mike, can you join us for dinner tonight", validMessage.getMessage());
        assertNotNull(validMessage.getMessageHash());
    }

    @Test
    public void testMessageStatusIsNullBeforeAnyAction() {
        assertNull(validMessage.getMessageStatus());
    }

    // ---------- checkMessageID ----------

    @Test
    public void testCheckMessageID_tenCharacters_returnsTrue() {
        assertTrue(validMessage.checkMessageID());
    }

    @Test
    public void testCheckMessageID_shorterThanTen_returnsTrue() {
        Quickchats m = new Quickchats("12345", 1, "+27718693002", "Hello");
        assertTrue(m.checkMessageID());
    }

    @Test
    public void testCheckMessageID_moreThanTen_returnsFalse() {
        Quickchats m = new Quickchats("12345678901", 1, "+27718693002", "Hello");
        assertFalse(m.checkMessageID());
    }

    @Test
    public void testCheckMessageID_null_returnsFalse() {
        Quickchats m = new Quickchats(null, 1, "+27718693002", "Hello");
        assertFalse(m.checkMessageID());
    }

    // ---------- checkRecipientCell ----------

    @Test
    public void testCheckRecipientCell_valid() {
        assertEquals("Cell phone number successfully captured.",
                validMessage.checkRecipientCell());
    }

    @Test
    public void testCheckRecipientCell_missingInternationalCode() {
        Quickchats m = new Quickchats("0012345678", 1, "0718693002", "Hello");
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code.",
                m.checkRecipientCell());
    }

    @Test
    public void testCheckRecipientCell_tooLong() {
        Quickchats m = new Quickchats("0012345678", 1, "+2771869300212", "Hello");
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code.",
                m.checkRecipientCell());
    }

    @Test
    public void testCheckRecipientCell_null() {
        Quickchats m = new Quickchats("0012345678", 1, null, "Hello");
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code.",
                m.checkRecipientCell());
    }

    // ---------- createMessageHash ----------

    @Test
    public void testCreateMessageHash_validMessage() {
        // prefix "00", message number 1, first word "Hi", last word "tonight"
        assertEquals("00:1:HITONIGHT", validMessage.createMessageHash());
        assertEquals("00:1:HITONIGHT", validMessage.getMessageHash());
    }

    @Test
    public void testCreateMessageHash_singleWordMessage() {
        Quickchats m = new Quickchats("0012345678", 2, "+27718693002", "Hello");
        assertEquals("00:2:HELLOHELLO", m.createMessageHash());
    }

    @Test
    public void testCreateMessageHash_removesPunctuation() {
        Quickchats m = new Quickchats("9912345678", 3, "+27718693002", "Hi, there!");
        assertEquals("99:3:HITHERE", m.createMessageHash());
    }

    @Test
    public void testCreateMessageHash_trimsWhitespace() {
        Quickchats m = new Quickchats("0012345678", 4, "+27718693002", "   Good morning   ");
        assertEquals("00:4:GOODMORNING", m.createMessageHash());
    }

    @Test
    public void testCreateMessageHash_isUpperCase() {
        String hash = validMessage.createMessageHash();
        assertEquals(hash.toUpperCase(), hash);
    }

    @Test
    public void testCreateMessageHash_idTooShort_returnsInvalid() {
        Quickchats m = new Quickchats("1", 1, "+27718693002", "Hello");
        assertEquals("00:0:INVALID", m.createMessageHash());
    }

    @Test
    public void testCreateMessageHash_nullId_returnsInvalid() {
        Quickchats m = new Quickchats(null, 1, "+27718693002", "Hello");
        assertEquals("00:0:INVALID", m.createMessageHash());
    }

    @Test
    public void testCreateMessageHash_emptyMessage_returnsInvalid() {
        Quickchats m = new Quickchats("0012345678", 1, "+27718693002", "");
        assertEquals("00:0:INVALID", m.createMessageHash());
    }

    @Test
    public void testCreateMessageHash_whitespaceOnlyMessage_returnsInvalid() {
        Quickchats m = new Quickchats("0012345678", 1, "+27718693002", "     ");
        assertEquals("00:0:INVALID", m.createMessageHash());
    }

    @Test
    public void testCreateMessageHash_nullMessage_returnsInvalid() {
        Quickchats m = new Quickchats("0012345678", 1, "+27718693002", null);
        assertEquals("00:0:INVALID", m.createMessageHash());
    }

    // ---------- SentMessage ----------

    @Test
    public void testSentMessage_send() {
        String result = validMessage.SentMessage(1);
        assertEquals("Message successfully sent.", result);
        assertEquals("Sent", validMessage.getMessageStatus());
        assertEquals(1, Quickchats.returnTotalMessages());
    }

    @Test
    public void testSentMessage_disregard() {
        String result = validMessage.SentMessage(2);
        assertEquals("Press 0 to delete the message.", result);
        assertEquals("Disregarded", validMessage.getMessageStatus());
        assertEquals(0, Quickchats.returnTotalMessages());
    }

    @Test
    public void testSentMessage_store() {
        String result = validMessage.SentMessage(3);
        assertEquals("Message successfully stored.", result);
        assertEquals("Stored", validMessage.getMessageStatus());
        assertEquals(0, Quickchats.returnTotalMessages());
    }

    @Test
    public void testSentMessage_invalidChoice() {
        assertEquals("Invalid choice", validMessage.SentMessage(99));
        assertEquals("Unknown", validMessage.getMessageStatus());
        assertEquals(0, Quickchats.returnTotalMessages());
    }

    @Test
    public void testSentMessage_zeroAndNegativeAreInvalid() {
        assertEquals("Invalid choice", validMessage.SentMessage(0));
        assertEquals("Invalid choice", validMessage.SentMessage(-1));
    }

    // ---------- returnTotalMessages ----------

    @Test
    public void testReturnTotalMessages_startsAtZero() {
        assertEquals(0, Quickchats.returnTotalMessages());
    }

    @Test
    public void testReturnTotalMessages_countsOnlySentMessages() {
        Quickchats second = new Quickchats("0112345678", 2, "+27718693002", "Second message");
        Quickchats third = new Quickchats("0212345678", 3, "+27718693002", "Third message");

        validMessage.SentMessage(1); // sent
        second.SentMessage(3);       // stored
        third.SentMessage(1);        // sent

        assertEquals(2, Quickchats.returnTotalMessages());
    }

    // ---------- generateMessageID ----------

    @Test
    public void testGenerateMessageID_isTenDigits() {
        for (int i = 0; i < 100; i++) {
            String id = Quickchats.generateMessageID();
            assertEquals(10, id.length());
            assertTrue("ID should be numeric: " + id, id.matches("\\d{10}"));
        }
    }

    @Test
    public void testGenerateMessageID_passesCheckMessageID() {
        Quickchats m = new Quickchats(Quickchats.generateMessageID(), 1, "+27718693002", "Hello");
        assertTrue(m.checkMessageID());
    }

    // ---------- printMessageDetails ----------

    @Test
    public void testPrintMessageDetails_containsAllFields() {
        Quickchats.printMessageDetails(validMessage);
        String output = outContent.toString();

        assertTrue(output.contains("Message ID: 0012345678"));
        assertTrue(output.contains("Message Hash: 00:1:HITONIGHT"));
        assertTrue(output.contains("Recipient: +27718693002"));
        assertTrue(output.contains("Message: Hi Mike, can you join us for dinner tonight"));
    }
}