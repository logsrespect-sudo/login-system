package javaapplicationpart1;

import java.io.ByteArrayInputStream;
import java.util.Scanner;
import org.junit.Test;
import static org.junit.Assert.*;

public class JavaApplicationPart1IT {

    // ==============================
    // USERNAME TESTS
    // ==============================

    @Test
    public void testValidUsername() {
        assertTrue(JavaApplicationPart1.checkUserName("ab_cd"));
    }

    @Test
    public void testUsernameWithoutUnderscore() {
        assertFalse(JavaApplicationPart1.checkUserName("abcde"));
    }

    @Test
    public void testUsernameMoreThan5Characters() {
        assertFalse(JavaApplicationPart1.checkUserName("abcdef"));
    }

    // ==============================
    // PASSWORD TESTS
    // ==============================

    @Test
    public void testValidPassword() {
        assertTrue(JavaApplicationPart1.checkPassword("Password1!"));
    }

    @Test
    public void testPasswordTooShort() {
        assertFalse(JavaApplicationPart1.checkPassword("Pass1!"));
    }

    @Test
    public void testPasswordWithoutCapitalLetter() {
        assertFalse(JavaApplicationPart1.checkPassword("password1!"));
    }

    @Test
    public void testPasswordWithoutNumber() {
        assertFalse(JavaApplicationPart1.checkPassword("Password!"));
    }

    @Test
    public void testPasswordWithoutSpecialCharacter() {
        assertFalse(JavaApplicationPart1.checkPassword("Password1"));
    }

    // ==============================
    // PHONE NUMBER TESTS
    // ==============================

    @Test
    public void testValidPhoneNumber() {
        assertTrue(JavaApplicationPart1.checkCellPhoneNumber("+27821234567"));
    }

    @Test
    public void testPhoneNumberWithoutInternationalCode() {
        assertFalse(JavaApplicationPart1.checkCellPhoneNumber("0821234567"));
    }

    @Test
    public void testPhoneNumberTooLong() {
        assertFalse(JavaApplicationPart1.checkCellPhoneNumber("+27821234567890"));
    }

    // ==============================
    // LOGIN STATUS TESTS
    // ==============================

    @Test
    public void testSuccessfulLoginStatus() {

        JavaApplicationPart1 user = new JavaApplicationPart1();

        user.name = "John";
        user.username = "jo_hn";

        String result = login.returnLoginStatus(user, true);

        assertEquals(
                "Welcome, John, jo_hnit is great to see you again",
                result
        );
    }

    @Test
    public void testFailedLoginStatus() {

        JavaApplicationPart1 user = new JavaApplicationPart1();

        String result = login.returnLoginStatus(user, false);

        assertEquals(
                "Username or Password is incorrect, Please try again",
                result
        );
    }

    // ==============================
    // LOGIN USER TEST
    // ==============================

    @Test
    public void testLoginUserSuccessful() {

        JavaApplicationPart1 user = new JavaApplicationPart1();

        user.name = "John";
        user.surname = "Smith";
        user.username = "jo_hn";
        user.password = "Password1!";

        // Simulate keyboard input
        String simulatedInput =
                "jo_hn\n"
                + "Password1!\n";

        ByteArrayInputStream input =
                new ByteArrayInputStream(simulatedInput.getBytes());

        Scanner scanner = new Scanner(input);

        boolean result = login.loginUser(scanner, user);

        assertTrue(result);
    }

    // ==============================
    // LOGIN USER - WRONG THEN RIGHT
    // ==============================

    @Test
    public void testLoginUserWrongPasswordThenCorrect() {

        JavaApplicationPart1 user = new JavaApplicationPart1();

        user.name = "John";
        user.username= "jo_hn";
        user.password = "Password1!";

        // First login attempt is incorrect.
        // Second login attempt is correct.
        String simulatedInput =
                "jo_hn\n"
                + "WrongPassword\n"
                + "jo_hn\n"
                + "Password1!\n";

        ByteArrayInputStream input =
                new ByteArrayInputStream(simulatedInput.getBytes());

        Scanner scanner = new Scanner(input);

        boolean result = login.loginUser(scanner, user);

        assertTrue(result);
    }
}