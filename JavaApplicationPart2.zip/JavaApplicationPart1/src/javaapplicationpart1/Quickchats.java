/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplicationpart1;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Quickchats {
    
      // Instance variables for each message
    private String messageID;
    private int messageNumber;
    private String recipient;
    private String message;
    private String messageHash;
    private String messageStatus;
    
    // Collection to store sent messages
    private static ArrayList<Quickchats> sentMessages = new ArrayList<>();
    
    // Constructor
    public Quickchats(String messageID, int messageNumber, String recipient, String message) {
        this.messageID = messageID;
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.message = message;
        this.messageHash = createMessageHash();
    }
    
    // 1. Ensures message ID is not more than ten characters
    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }
    
    // 2. Ensures recipient cell number is valid and starts with '+'
    public String checkRecipientCell() {
        if (recipient != null && recipient.startsWith("+") && recipient.length() <= 12) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain an international code.";
    }
    
    // 3. Creates and returns the Message Hash
    public String createMessageHash() {
        if (messageID == null || messageID.length() < 2 || message == null || message.trim().isEmpty()) {
            return "00:0:INVALID";
        }
        String prefix = messageID.substring(0, 2);
        
        String trimmedMsg = message.trim().replaceAll("[^a-zA-Z0-9\\s]", "");
        String[] words = trimmedMsg.split("\\s+");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 0 ? words[words.length - 1] : "";
        
        return (prefix + ":" + messageNumber + ":" + firstWord + lastWord).toUpperCase();
    }
    
    // 4. Allows user to choose if they want to send, store, or disregard the message
    public String SentMessage(int choice) {
        switch (choice) {
            case 1:
                this.messageStatus = "Sent";
                sentMessages.add(this);
                return "Message successfully sent.";
            case 2:
                this.messageStatus = "Disregarded";
                return "Press 0 to delete the message.";
            case 3:
                this.messageStatus = "Stored";
                return "Message successfully stored.";
            default:
                this.messageStatus = "Unknown";
                return "Invalid choice";
        }
    }
    
    // 5. Returns the total number of messages sent
    public static int returnTotalMessages() {
        return sentMessages.size();
    }
    
    // 6. Helper method to generate a random 10-digit ID
    public static String generateMessageID() {
        Random rand = new Random();
        long id = 1000000000L + (long)(rand.nextDouble() * 9000000000L);
        return String.valueOf(id);
    }
    
    // 7. Displays full message details
    public static void printMessageDetails(Quickchats m) {
        System.out.println("\n-----------------------------");
        System.out.println("Message ID: " + m.getMessageID());
        System.out.println("Message Hash: " + m.getMessageHash());
        System.out.println("Recipient: " + m.getRecipient());
        System.out.println("Message: " + m.getMessage());
        System.out.println("-----------------------------");
    }

    // Getters
    public String getMessageID() { return messageID; }
    public int getMessageNumber() { return messageNumber; }
    public String getRecipient() { return recipient; }
    public String getMessage() { return message; }
    public String getMessageHash() { return messageHash; }
    public String getMessageStatus() { return messageStatus; }
}