/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package javaapplicationpart1;

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Student
 */
public class Qchatspart3IT {
    
    public Qchatspart3IT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of checkMessageID method, of class Qchatspart3.
     */
    @Test
    public void testCheckMessageID() {
        System.out.println("checkMessageID");
        Qchatspart3 instance = null;
        boolean expResult = false;
        boolean result = instance.checkMessageID();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of checkRecipientCell method, of class Qchatspart3.
     */
    @Test
    public void testCheckRecipientCell() {
        System.out.println("checkRecipientCell");
        Qchatspart3 instance = null;
        String expResult = "";
        String result = instance.checkRecipientCell();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of createMessageHash method, of class Qchatspart3.
     */
    @Test
    public void testCreateMessageHash() {
        System.out.println("createMessageHash");
        Qchatspart3 instance = null;
        String expResult = "";
        String result = instance.createMessageHash();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of SentMessage method, of class Qchatspart3.
     */
    @Test
    public void testSentMessage() {
        System.out.println("SentMessage");
        int choice = 0;
        Qchatspart3 instance = null;
        String expResult = "";
        String result = instance.SentMessage(choice);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of returnTotalMessages method, of class Qchatspart3.
     */
    @Test
    public void testReturnTotalMessages() {
        System.out.println("returnTotalMessages");
        int expResult = 0;
        int result = Qchatspart3.returnTotalMessages();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of generateMessageID method, of class Qchatspart3.
     */
    @Test
    public void testGenerateMessageID() {
        System.out.println("generateMessageID");
        String expResult = "";
        String result = Qchatspart3.generateMessageID();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of printMessageDetails method, of class Qchatspart3.
     */
    @Test
    public void testPrintMessageDetails() {
        System.out.println("printMessageDetails");
        Quickchats m = null;
        Qchatspart3.printMessageDetails(m);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of registerHashAndID method, of class Qchatspart3.
     */
    @Test
    public void testRegisterHashAndID() {
        System.out.println("registerHashAndID");
        Quickchats m = null;
        Qchatspart3.registerHashAndID(m);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of clearAllArrays method, of class Qchatspart3.
     */
    @Test
    public void testClearAllArrays() {
        System.out.println("clearAllArrays");
        Qchatspart3.clearAllArrays();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSentMessages method, of class Qchatspart3.
     */
    @Test
    public void testGetSentMessages() {
        System.out.println("getSentMessages");
        ArrayList<Quickchats> expResult = null;
        ArrayList<Quickchats> result = Qchatspart3.getSentMessages();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDisregardedMessages method, of class Qchatspart3.
     */
    @Test
    public void testGetDisregardedMessages() {
        System.out.println("getDisregardedMessages");
        ArrayList<Quickchats> expResult = null;
        ArrayList<Quickchats> result = Qchatspart3.getDisregardedMessages();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getStoredMessages method, of class Qchatspart3.
     */
    @Test
    public void testGetStoredMessages() {
        System.out.println("getStoredMessages");
        ArrayList<Quickchats> expResult = null;
        ArrayList<Quickchats> result = Qchatspart3.getStoredMessages();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getMessageHashes method, of class Qchatspart3.
     */
    @Test
    public void testGetMessageHashes() {
        System.out.println("getMessageHashes");
        ArrayList<String> expResult = null;
        ArrayList<String> result = Qchatspart3.getMessageHashes();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getMessageIDs method, of class Qchatspart3.
     */
    @Test
    public void testGetMessageIDs() {
        System.out.println("getMessageIDs");
        ArrayList<String> expResult = null;
        ArrayList<String> result = Qchatspart3.getMessageIDs();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getMessageID method, of class Qchatspart3.
     */
    @Test
    public void testGetMessageID() {
        System.out.println("getMessageID");
        Qchatspart3 instance = null;
        String expResult = "";
        String result = instance.getMessageID();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getMessageNumber method, of class Qchatspart3.
     */
    @Test
    public void testGetMessageNumber() {
        System.out.println("getMessageNumber");
        Qchatspart3 instance = null;
        int expResult = 0;
        int result = instance.getMessageNumber();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getRecipient method, of class Qchatspart3.
     */
    @Test
    public void testGetRecipient() {
        System.out.println("getRecipient");
        Qchatspart3 instance = null;
        String expResult = "";
        String result = instance.getRecipient();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getMessage method, of class Qchatspart3.
     */
    @Test
    public void testGetMessage() {
        System.out.println("getMessage");
        Qchatspart3 instance = null;
        String expResult = "";
        String result = instance.getMessage();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getMessageStatus method, of class Qchatspart3.
     */
    @Test
    public void testGetMessageStatus() {
        System.out.println("getMessageStatus");
        Qchatspart3 instance = null;
        String expResult = "";
        String result = instance.getMessageStatus();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setMessageStatus method, of class Qchatspart3.
     */
    @Test
    public void testSetMessageStatus() {
        System.out.println("setMessageStatus");
        String status = "";
        Qchatspart3 instance = null;
        instance.setMessageStatus(status);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getMessageHash method, of class Qchatspart3.
     */
    @Test
    public void testGetMessageHash() {
        System.out.println("getMessageHash");
        Qchatspart3 instance = null;
        String expResult = "";
        String result = instance.getMessageHash();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
